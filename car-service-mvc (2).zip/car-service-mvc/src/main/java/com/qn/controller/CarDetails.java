package com.qn.controller;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.qn.model.Car;
import com.qn.model.Customer;
public class CarDetails extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	
	String cm=request.getParameter("carmodel");
	String ct=request.getParameter("cartype");
	String crn=request.getParameter("carregisternumber");
	HttpSession session = request.getSession(true);
	String username=(String)session.getAttribute("username");
	Car c=new Car();
	c.setUsername(username);
	c.setCm(cm);
	c.setCt(ct);
	c.setCrn(crn);
	int status=c.cardetails();
	if(status==0) {
		response.sendRedirect("/car-service-mvc/cardetailsfailure.jsp");
	}
	else {
		response.sendRedirect("/car-service-mvc/cardetailssucess.jsp");

	}
}
}
