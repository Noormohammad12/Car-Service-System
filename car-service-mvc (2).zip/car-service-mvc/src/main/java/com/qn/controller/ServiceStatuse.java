package com.qn.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.qn.model.Car;

public class ServiceStatuse extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String crn=request.getParameter("crn");
		Car c=new Car();
		c.setCrn(crn);
		String s=c.servicestatus();
		HttpSession session=request.getSession(true);
		session.setAttribute("status", s);
		response.sendRedirect("/car-service-mvc/status.jsp");
	}
}
