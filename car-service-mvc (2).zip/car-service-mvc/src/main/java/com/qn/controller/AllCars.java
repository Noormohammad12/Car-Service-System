package com.qn.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.qn.model.Car;

public class AllCars extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		Car c=new Car();
		ArrayList<Car> allcars=c.viewallcars();
		if(allcars==null) {
			response.sendRedirect("/car-service-mvc/viewallcarsfailure.jsp");
		}
		else {
			session.setAttribute("allcars", allcars);
			response.sendRedirect("/car-service-mvc/viewallcarssuccess.jsp");
		}
	}

}
