package com.qn.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.qn.model.Car;


public class ServiceRequest extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String servicerequest=request.getParameter("service_request");
		String crn=request.getParameter("crn");
		Car c=new Car();
		HttpSession session=request.getSession(true);
		String username=(String)session.getAttribute("username");
		c.setCrn(crn);
		c.setSr(servicerequest);
		c.setUsername(username);
		int r=c.servicerequest();
		if(r==0) {
			response.sendRedirect("/car-service-mvc/request_failure.jsp");
		}
		else {
			response.sendRedirect("/car-service-mvc/request_success.jsp");
		}
	}

}
