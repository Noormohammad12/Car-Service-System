package com.qn.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.qn.model.Customer;


public class AllCustomers extends HttpServlet {
@Override
protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	Customer c=new Customer();
	ArrayList<Customer> customerdetails=c.customerdetails();
	HttpSession session=request.getSession();
	session.setAttribute("scd", customerdetails);
	if(customerdetails==null) {
		response.sendRedirect("/car-service-mvc/viewcustomerfailure.jsp");
	}
	else {
		response.sendRedirect("/car-service-mvc/viewcustomersuccess.jsp");

	}
}	
}
