package com.qn.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class Car {
	private String cm;
	private String ct;
	private String crn;
	private String sr;
	private String ss;
	private String username;
	public Car(String cm, String ct, String crn, String sr, String ss, String username) {
		super();
		this.cm = cm;
		this.ct = ct;
		this.crn = crn;
		this.sr = sr;
		this.ss = ss;
		this.username = username;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	Connection con;
	public String getCm() {
		return cm;
	}
	public void setCm(String cm) {
		this.cm = cm;
	}
	public String getCt() {
		return ct;
	}
	public void setCt(String ct) {
		this.ct = ct;
	}
	public String getCrn() {
		return crn;
	}
	public void setCrn(String crn) {
		this.crn = crn;
	}
	public String getSr() {
		return sr;
	}
	public void setSr(String sr) {
		this.sr = sr;
	}
	public String getSs() {
		return ss;
	}
	public void setSs(String ss) {
		this.ss = ss;
	}
	@Override
	public String toString() {
		return "Student [cm=" + cm + ", ct=" + ct + ", crn=" + crn + ", sr=" + sr + ", ss=" + ss + ", username="
				+ username + "]";
	}
	public Car(String cm, String ct, String crn, String sr, String ss) {
		super();
		this.cm = cm;
		this.ct = ct;
		this.crn = crn;
		this.sr = sr;
		this.ss = ss;
	}
	public Car() {
		super();
		// TODO Auto-generated constructor stub
	}
	{
		try {
			DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/june_2024","root","root");
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
	}
	public int cardetails() {
		try {
			String s="insert into car values(?,?,?,?,?,?)";
		    PreparedStatement pstmt=con.prepareStatement(s);
		    pstmt.setString(1,username);
		    pstmt.setString(2,cm);
		    pstmt.setString(3,ct);
		    pstmt.setString(4,crn);
		    pstmt.setString(5,"NA");
		    pstmt.setString(6,"NA");
		    int rows=pstmt.executeUpdate();
		    return rows;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return 0;
	}
	public int servicerequest() {
		try {
			String s="update car set service_request=?,service_status=? where username=? and car_registration_number=?";
			PreparedStatement pstmt=con.prepareStatement(s);
			pstmt.setString(1, sr);
			pstmt.setString(2, "pending");
			pstmt.setString(3, username);
			pstmt.setString(4, crn);
			int rows=pstmt.executeUpdate();
			return rows;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
	public String servicestatus(){
		try {
		String s="select * from car where car_registration_number=?";
		PreparedStatement pstmt=con.prepareStatement(s);
		pstmt.setString(1,crn);
		ResultSet res=pstmt.executeQuery();
		if(res.next()) {
			String s1=res.getString(6);
			return s1;
		}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	public ArrayList<Car> viewallcars(){
		try{
			String s="select * from car";
			PreparedStatement pstmt=con.prepareStatement(s);
			ResultSet res=pstmt.executeQuery();
			ArrayList<Car> allcars=new ArrayList<>();
			while(res.next()) {
				username=res.getString(1);
				cm=res.getString(2);
				ct=res.getString(3);
				crn=res.getString(4);
				sr=res.getString(5);
				ss=res.getString(6);
				allcars.add(new Car(username,cm,ct,crn,sr,ss));
			}
			return allcars;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	public int updatecarmodel() {
		try {
			String s="update car set car_model=? where car_registration_number=?";
			PreparedStatement pstmt=con.prepareStatement(s);
			pstmt.setString(1,cm);
			pstmt.setString(2, crn);
			int rows=pstmt.executeUpdate();
			return rows;
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

}
